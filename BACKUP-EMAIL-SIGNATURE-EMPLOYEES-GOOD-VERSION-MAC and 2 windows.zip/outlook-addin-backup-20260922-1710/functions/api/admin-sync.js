// Receives an automatic preview push from the Signature Console the moment
// an employee's card is Approved there — no manual export/build/wrangler
// step needed. Writes straight into the same KV store /api/signature.js
// reads from, under the same "sig:" + lowercased-email key it already uses.
//
// This ONLY updates the Outlook add-in's preview pane. It never touches
// Exchange transport rules or runs any PowerShell — the real, applied
// signature still only changes when Deploy-Signature.ps1 is actually run.
//
// Protected by a shared secret (ADMIN_SYNC_SECRET, set via
// `wrangler pages secret put ADMIN_SYNC_SECRET`) sent as the
// x-admin-sync-secret header. This is a light deterrent against random
// crawlers hitting a guessable path, not real security — same trust level
// as the PIN it replaces in the Console.
export async function onRequestPost(context) {
  const { request, env } = context;

  if (!env.SIGNATURES) return json({ error: "kv_not_configured" }, 500);
  if (!env.ADMIN_SYNC_SECRET) return json({ error: "secret_not_configured" }, 500);

  const gotSecret = request.headers.get("x-admin-sync-secret") || "";
  if (gotSecret !== env.ADMIN_SYNC_SECRET) {
    return json({ error: "unauthorized" }, 401);
  }

  let body;
  try {
    body = await request.json();
  } catch (e) {
    return json({ error: "invalid_json" }, 400);
  }

  const emailRaw = (body && body.email) || "";
  const email = String(emailRaw).trim().toLowerCase();
  if (!email) return json({ error: "missing_email" }, 400);

  const payload = body && body.payload;
  if (!payload || typeof payload !== "object") {
    return json({ error: "missing_payload" }, 400);
  }

  await env.SIGNATURES.put("sig:" + email, JSON.stringify(payload));

  return json({ ok: true, email, syncedAt: payload.syncedAt || null }, 200);
}

function json(obj, status) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}
