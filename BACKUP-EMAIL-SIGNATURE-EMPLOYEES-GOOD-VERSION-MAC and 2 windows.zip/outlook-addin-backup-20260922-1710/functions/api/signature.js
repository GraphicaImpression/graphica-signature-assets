// Cloudflare Pages Function — GET /api/signature?email=...
//
// Reads one employee's compiled signature/banner/variant data from the
// SIGNATURES KV namespace (bound in the Pages project settings) and returns
// it as JSON for the task pane to render. The KV store is filled by the
// separate manual sync script (sync/push-to-cloudflare.js) — this function
// only ever reads, it never writes, so a broken or stale KV entry can't come
// from anything running here.
//
// KV key shape: "sig:<lowercased email>" -> JSON string (see sync script for
// the exact fields written).

export async function onRequestGet(context) {
  const { request, env } = context;
  const url = new URL(request.url);
  const emailRaw = url.searchParams.get("email") || "";
  const email = emailRaw.trim().toLowerCase();

  if (!email) {
    return json({ error: "missing_email" }, 400);
  }

  if (!env.SIGNATURES) {
    // KV binding not configured yet — a clear error beats a silent 500.
    return json({ error: "kv_not_configured" }, 500);
  }

  const stored = await env.SIGNATURES.get("sig:" + email);
  if (!stored) {
    return json({ error: "not_found" }, 404);
  }

  return new Response(stored, {
    status: 200,
    headers: {
      "content-type": "application/json; charset=utf-8",
      // Short cache only — someone may re-sync at any time and expects the
      // panel to pick it up on the next "Rafraîchir" or task-pane reopen,
      // not be stuck behind a long-lived cache.
      "cache-control": "private, max-age=30",
    },
  });
}

function json(obj, status) {
  return new Response(JSON.stringify(obj), {
    status: status || 200,
    headers: { "content-type": "application/json; charset=utf-8" },
  });
}
