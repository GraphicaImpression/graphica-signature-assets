#!/usr/bin/env node
// Run by the recurring "sync check" scheduled task (NOT by the Console
// itself — a published Claude Artifact can't make outbound network calls,
// so the Console can only ever prepare data, never push it). This script:
//   1. reads one employee's doc + the company config (both exported ahead of
//      time by the scheduled task via the Artifact tool's read_db, since
//      only a live Claude session can call that — this script never talks to
//      the Console's database directly)
//   2. decides whether that employee needs a fresh push (status is
//      "approuvé" AND either never synced, or synced before their last
//      approval)
//   3. if so, builds the same literal/token-free preview payload
//      sync/build-kv-entries.js has always built by hand, and POSTs it to
//      the add-in's /api/admin-sync endpoint
//   4. prints a single machine-readable line the scheduled task reads back:
//        SYNCED <ISO timestamp>   — pushed successfully, write this back as
//                                   this employee's syncedAt in the Console
//        SKIPPED <reason>         — nothing to do this run
//        FAILED <error message>   — push attempted but failed; nothing was
//                                   written, try again next run
//
// This deliberately never touches Exchange, PowerShell, or the transport
// rules — it only keeps the Outlook add-in's preview pane in sync with the
// Console's last approval.
//
// Usage:
//   node auto-sync-check.js <employee.json> <company.json>
// Env:
//   ADMIN_SYNC_URL    (default: https://graphica-signatures.pages.dev/api/admin-sync)
//   ADMIN_SYNC_SECRET (required)

const fs = require("fs");

const NO_TITLE_PLACEHOLDER = "(titre du répertoire — non disponible dans cet aperçu)";

function esc(s) {
  return String(s || "");
}

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

function bannerPreviewHtml(mode, imageUrl, rawHtml) {
  if (mode === "image" && imageUrl) {
    return `<img src="${esc(imageUrl)}" alt="" style="max-width:100%;display:block;">`;
  }
  return rawHtml || null;
}

function autoImageBannerHtml(url) {
  if (!url) return null;
  return `<img src="${esc(url)}" alt="" style="max-width:100%;display:block;">`;
}

function effectiveVariantFields(emp, variant) {
  const merged = {};
  ["nameOverride", "titleOverride", "phoneOverride", "emailOverride", "addressOverride", "websiteUrlOverride", "websiteLabelOverride", "logoOverride"].forEach((k) => {
    merged[k] = variant[k] || emp[k] || null;
  });
  merged.bannerMode = variant.bannerMode || emp.bannerMode || "auto";
  merged.promoMode = variant.promoMode || emp.promoMode || "auto";
  merged.bannerOverrideHtml = variant.bannerOverrideHtml || autoImageBannerHtml(variant.bannerImageUrl) || emp.bannerOverrideHtml || null;
  merged.promoOverrideHtml = variant.promoOverrideHtml || autoImageBannerHtml(variant.promoImageUrl) || emp.promoOverrideHtml || null;
  merged.displayName = emp.displayName;
  merged.email = emp.email;
  return merged;
}

function resolveBannerForPreview(effective, company) {
  const on = effective.bannerMode === "on" ? true : effective.bannerMode === "off" ? false : !!company.seasonalBannerEnabled;
  if (!on) return null;
  if (effective.bannerOverrideHtml) return effective.bannerOverrideHtml;
  return bannerPreviewHtml(company.seasonalBannerMode, company.seasonalImageUrl, company.seasonalBannerHtml);
}
function resolvePromoForPreview(effective, company) {
  const on = effective.promoMode === "on" ? true : effective.promoMode === "off" ? false : !!company.promoBannerEnabled;
  if (!on) return null;
  if (effective.promoOverrideHtml) return effective.promoOverrideHtml;
  return bannerPreviewHtml(company.promoBannerMode, company.promoImageUrl, company.promoBannerHtml);
}

// Mirrors generate() in signature-console.html closely enough for preview
// purposes (used for variant "Copier le code HTML" style output only —
// nothing here is deployed to Exchange).
function generateLikeConsole(effective, company) {
  const nameEff = effective.nameOverride || "%%DisplayName%%";
  const titleEff = effective.titleOverride || "%%Title%%";
  const phoneEff = effective.phoneOverride || company.companyPhone || "";
  const emailEff = effective.emailOverride || "%%Email%%";
  const addressEff = effective.addressOverride || company.companyAddress || "";
  const webUrlEff = effective.websiteUrlOverride || company.companyWebsiteUrl || "";
  const webLabelEff = effective.websiteLabelOverride || company.companyWebsiteLabel || "";
  const logoEff = effective.logoOverride || company.companyLogoUrl || "";
  const bannerBlock = resolveBannerForPreview(effective, company) ? (effective.bannerOverrideHtml || company.seasonalBannerHtml || "") : "";
  const promoBlock = resolvePromoForPreview(effective, company) ? (effective.promoOverrideHtml || company.promoBannerHtml || "") : "";
  return [
    logoEff ? `<div><img src="${esc(logoEff)}" alt="" style="max-width:160px;display:block;margin-bottom:8px;"></div>` : "",
    `<div><b>${nameEff}</b></div>`,
    `<div style="color:#0768ad;">${titleEff}</div>`,
    phoneEff ? `<div>Tel ${phoneEff}</div>` : "",
    `<div>${emailEff}</div>`,
    addressEff ? `<div>${addressEff}</div>` : "",
    webUrlEff ? `<div><a href="${webUrlEff}">${webLabelEff || webUrlEff}</a></div>` : "",
    bannerBlock,
    promoBlock,
  ].filter(Boolean).join("\n");
}

function buildPayload(emp, company, syncedAt) {
  const bannerPreview = resolveBannerForPreview(emp, company);
  const promoPreview = resolvePromoForPreview(emp, company);
  return {
    displayName: emp.nameOverride || emp.displayName || "",
    title: emp.titleOverride || NO_TITLE_PLACEHOLDER,
    phone: emp.phoneOverride || company.companyPhone || "",
    email: emp.emailOverride || emp.email || "",
    websiteUrl: emp.websiteUrlOverride || company.companyWebsiteUrl || "",
    websiteLabel: emp.websiteLabelOverride || company.companyWebsiteLabel || "",
    logoUrl: emp.logoOverride || company.companyLogoUrl || "",
    companyName: company.companyName || "",
    bannerHtmlPreview: bannerPreview,
    promoHtmlPreview: promoPreview,
    variants: (emp.variants || []).map((v) => {
      const effective = effectiveVariantFields(emp, v);
      return { label: v.label || "", html: generateLikeConsole(effective, company) };
    }),
    syncedAt,
  };
}

async function main() {
  const [empPath, companyPath] = process.argv.slice(2);
  if (!empPath || !companyPath) {
    console.log("FAILED missing arguments: usage: node auto-sync-check.js <employee.json> <company.json>");
    process.exit(1);
  }
  const emp = readJson(empPath);
  const company = readJson(companyPath);

  if (emp.status !== "approuvé") {
    console.log("SKIPPED not approved");
    return;
  }
  const approvedAt = emp.approvedAt ? new Date(emp.approvedAt).getTime() : 0;
  const syncedAtExisting = emp.syncedAt ? new Date(emp.syncedAt).getTime() : 0;
  if (syncedAtExisting >= approvedAt && approvedAt > 0) {
    console.log("SKIPPED already synced");
    return;
  }
  if (!emp.email) {
    console.log("FAILED employee has no email");
    return;
  }

  const secret = process.env.ADMIN_SYNC_SECRET;
  if (!secret) {
    console.log("FAILED ADMIN_SYNC_SECRET not set in environment");
    return;
  }
  const url = process.env.ADMIN_SYNC_URL || "https://graphica-signatures.pages.dev/api/admin-sync";

  const syncedAt = new Date().toISOString();
  const payload = buildPayload(emp, company, syncedAt);
  const email = emp.email.trim().toLowerCase();

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json", "x-admin-sync-secret": secret },
      body: JSON.stringify({ email, payload }),
    });
    if (!res.ok) {
      const text = await res.text().catch(() => "");
      console.log(`FAILED HTTP ${res.status} ${text}`);
      return;
    }
    console.log(`SYNCED ${syncedAt}`);
  } catch (err) {
    console.log(`FAILED ${err && err.message ? err.message : err}`);
  }
}

main();
