#!/usr/bin/env node
// Transforms a raw dump of the Signature Console's database (employees.json
// + company.json, both pulled via the Artifact tool's read_db) into a
// wrangler-compatible bulk-KV file (kv-bulk.json), ready for:
//   wrangler kv bulk put kv-bulk.json --binding=SIGNATURES [--remote]
//
// This deliberately RE-IMPLEMENTS (not imports) the same effective-value
// logic as generate() / effectiveVariantFields() in signature-console.html,
// because that file's functions only exist inside the Console's own browser
// context — nothing here reads from or writes back to the Console itself.
// If those functions in signature-console.html ever change, this file needs
// the matching update by hand.
//
// KNOWN GAP: an employee's real Title comes from Exchange/Azure AD at send
// time (the %%Title%% token), which the Console never sees unless a person
// has a manual "titleOverride" set. For anyone without one, this script
// cannot show their real title in the Add-in preview — it shows a plain
// placeholder instead of guessing. Closing this would mean pulling job
// titles from Microsoft Graph (the same way Update-EmployeeAttributes.ps1
// already pulls phone numbers) — a reasonable follow-up, not done here.

const fs = require("fs");
const path = require("path");

const DIR = __dirname;
const employees = readJson(path.join(DIR, "employees.json"));
const company = readJson(path.join(DIR, "company.json"));

if (!Array.isArray(employees)) {
  console.error("employees.json must be a JSON array of employee objects (each with its Console doc id merged in as `id`).");
  process.exit(1);
}
if (!company || typeof company !== "object") {
  console.error("company.json must be the company config JSON object.");
  process.exit(1);
}

const NO_TITLE_PLACEHOLDER = "(titre du répertoire — non disponible dans cet aperçu)";
const syncedAt = new Date().toISOString();

function readJson(p) {
  try {
    return JSON.parse(fs.readFileSync(p, "utf8"));
  } catch (e) {
    console.error("Could not read/parse " + p + ": " + e.message);
    process.exit(1);
  }
}

function esc(s) {
  return String(s || "");
}

// Mirrors buildSeasonalImageHtml()/company.seasonalBannerHtml usage in the
// Console closely enough for preview purposes: an <img> tag when an image
// URL is set, or the raw seasonalBannerHtml/promoBannerHtml table-row HTML
// otherwise (already valid standalone HTML, safe to drop into the task
// pane's innerHTML as-is since it's the same trusted content already live
// in the Console).
function bannerPreviewHtml(mode, imageUrl, rawHtml) {
  if (mode === "image" && imageUrl) {
    return `<img src="${esc(imageUrl)}" alt="" style="max-width:100%;display:block;">`;
  }
  return rawHtml || null;
}

function effectiveVariantFields(emp, variant) {
  const merged = {};
  ["nameOverride","titleOverride","phoneOverride","emailOverride","addressOverride","websiteUrlOverride","websiteLabelOverride","logoOverride"].forEach((k) => {
    merged[k] = variant[k] || emp[k] || null;
  });
  merged.bannerMode = variant.bannerMode || emp.bannerMode || "auto";
  merged.promoMode = variant.promoMode || emp.promoMode || "auto";
  merged.bannerOverrideHtml = variant.bannerOverrideHtml || autoImageBannerHtml(variant.bannerImageUrl) || emp.bannerOverrideHtml || null;
  merged.promoOverrideHtml = variant.promoOverrideHtml || autoImageBannerHtml(variant.promoImageUrl) || emp.promoOverrideHtml || null;
  merged.displayName = emp.displayName;
  merged.email = emp.email;
  return merged;
}

function autoImageBannerHtml(url) {
  if (!url) return null;
  return `<img src="${esc(url)}" alt="" style="max-width:100%;display:block;">`;
}

function resolveBannerForPreview(effective) {
  const on = effective.bannerMode === "on" ? true : effective.bannerMode === "off" ? false : !!company.seasonalBannerEnabled;
  if (!on) return null;
  if (effective.bannerOverrideHtml) return effective.bannerOverrideHtml;
  return bannerPreviewHtml(company.seasonalBannerMode, company.seasonalImageUrl, company.seasonalBannerHtml);
}
function resolvePromoForPreview(effective) {
  const on = effective.promoMode === "on" ? true : effective.promoMode === "off" ? false : !!company.promoBannerEnabled;
  if (!on) return null;
  if (effective.promoOverrideHtml) return effective.promoOverrideHtml;
  return bannerPreviewHtml(company.promoBannerMode, company.promoImageUrl, company.promoBannerHtml);
}

// Builds the full raw HTML for a variant exactly the way the Console's own
// generate() would (used for the "Copier le code HTML" button — that one
// needs the REAL production HTML, tokens included, since it's meant to be
// pasted as an actual Outlook signature, not just previewed).
function generateLikeConsole(effective) {
  const nameEff = effective.nameOverride || "%%DisplayName%%";
  const titleEff = effective.titleOverride || "%%Title%%";
  const phoneEff = effective.phoneOverride || company.companyPhone || "";
  const emailEff = effective.emailOverride || "%%Email%%";
  const addressEff = effective.addressOverride || company.companyAddress || "";
  const webUrlEff = effective.websiteUrlOverride || company.companyWebsiteUrl || "";
  const webLabelEff = effective.websiteLabelOverride || company.companyWebsiteLabel || "";
  const logoEff = effective.logoOverride || company.companyLogoUrl || "";
  const bannerBlock = resolveBannerForPreview(effective) ? (effective.bannerOverrideHtml || company.seasonalBannerHtml || "") : "";
  const promoBlock = resolvePromoForPreview(effective) ? (effective.promoOverrideHtml || company.promoBannerHtml || "") : "";
  return [
    logoEff ? `<div><img src="${esc(logoEff)}" alt="" style="max-width:160px;display:block;margin-bottom:8px;"></div>` : "",
    `<div><b>${nameEff}</b></div>`,
    `<div style="color:#0768ad;">${titleEff}</div>`,
    phoneEff ? `<div>Tel ${phoneEff}</div>` : "",
    `<div>${emailEff}</div>`,
    addressEff ? `<div>${addressEff}</div>` : "",
    webUrlEff ? `<div><a href="${webUrlEff}">${webLabelEff || webUrlEff}</a></div>` : "",
    bannerBlock,
    promoBlock,
  ].filter(Boolean).join("\n");
}

const kvEntries = [];

employees.forEach((emp) => {
  if (!emp.email) return; // can't key an entry without an email
  const bannerPreview = resolveBannerForPreview(emp);
  const promoPreview = resolvePromoForPreview(emp);

  const payload = {
    displayName: emp.nameOverride || emp.displayName || "",
    title: emp.titleOverride || NO_TITLE_PLACEHOLDER,
    phone: emp.phoneOverride || company.companyPhone || "",
    email: emp.emailOverride || emp.email || "",
    websiteUrl: emp.websiteUrlOverride || company.companyWebsiteUrl || "",
    websiteLabel: emp.websiteLabelOverride || company.companyWebsiteLabel || "",
    logoUrl: emp.logoOverride || company.companyLogoUrl || "",
    companyName: company.companyName || "",
    bannerHtmlPreview: bannerPreview,
    promoHtmlPreview: promoPreview,
    variants: (emp.variants || []).map((v) => {
      const effective = effectiveVariantFields(emp, v);
      return {
        label: v.label || "",
        html: generateLikeConsole(effective),
      };
    }),
    syncedAt,
  };

  kvEntries.push({
    key: "sig:" + emp.email.trim().toLowerCase(),
    value: JSON.stringify(payload),
  });
});

const outPath = path.join(DIR, "kv-bulk.json");
fs.writeFileSync(outPath, JSON.stringify(kvEntries, null, 2));
console.log(`Wrote ${kvEntries.length} entries to ${outPath}`);
console.log("Next: wrangler kv bulk put kv-bulk.json --binding=SIGNATURES --remote  (run from the outlook-addin project directory, or pass --namespace-id)");
