// Graphica Signature Preview — task pane logic.
//
// EVERYDAY (DEFAULT) SIGNATURE: as of this version, this panel DOES insert it
// directly into the body — for a brand-new email immediately when compose
// opens, and for a Reply/Reply All/Forward whenever no other choice has been
// remembered for that conversation (see "CONVERSATION MEMORY" below). This is
// a change from the earlier preview-only behavior. It uses the exact same
// Office.js primitive as variants (item.body.setSignatureAsync — see next
// paragraph), and the exact same anti-double-signature mechanism: inserting
// ANYTHING here — default or variant — sets the hidden header that tells
// Exchange's transport rule to skip its own stamp on this message. Someone on
// an older Outlook client that doesn't support this (see
// supportsOverrideInsert() below) sees the old preview-only, copy-paste-only
// experience, completely unchanged — nothing here touches that fallback path.
//
// VARIANTS ("Signatures disponibles"): inserted directly into the message
// someone is currently writing, via Office.js's item.body.setSignatureAsync —
// so a non-technical employee just clicks the visual they want instead of
// copy/pasting HTML into Outlook's own signature settings. See manifest.xml's
// header comment for how this avoids ending up with two signatures on the
// same email (a hidden internet header flags the message, and the Exchange
// rule is configured to skip its own stamp when that flag is present).
//
// CONVERSATION MEMORY: the first time any signature (default or a variant) is
// used on a message, if that message is a Reply/Reply All/Forward (i.e. part
// of an existing conversation), that choice is remembered against the
// conversation's id via Office.context.roamingSettings — a small per-mailbox
// store Outlook itself keeps in sync. The NEXT time this panel opens on any
// message in that same conversation with nothing chosen yet, it automatically
// re-applies that same remembered choice instead of falling back to default.
// Whatever was most recently used in a conversation simply overwrites the
// remembered value — there's no extra logic for "did they switch mid-thread",
// by design (see conversation history for why this simpler rule was chosen).
(function () {
  "use strict";

  var els = {};

  // Exchange's transport rule (see Deploy-Signature.ps1) is configured with
  // an exception: skip appending the default signature if this header is
  // present with this exact value. IMPORTANT: Exchange's HeaderContainsWords
  // match is WHOLE-WORD ONLY (Microsoft's own docs: "contoso" matches
  // " Contoso" but does NOT match "AcontosoContosoaAcontosob") — so this
  // header's value must be nothing but the flag word itself, with nothing
  // else glued onto it, or the exception silently never matches. Which
  // signature is active — a specific variant's own id, or the special
  // DEFAULT_SENTINEL value meaning "the everyday signature" — lives in a
  // SEPARATE header instead, since Exchange never reads it.
  var OVERRIDE_HEADER_NAME = "X-Graphica-Signature-Override";
  var OVERRIDE_HEADER_VALUE = "true";
  var OVERRIDE_VARIANT_HEADER_NAME = "X-Graphica-Signature-Variant-Id";
  var DEFAULT_SENTINEL = "__default__";

  // Key inside Office.context.roamingSettings holding the conversation-id ->
  // chosen-signature-id map described above. Values are either a real
  // variant id or DEFAULT_SENTINEL. Capped defensively (see
  // rememberSignatureForConversation) so years of daily use can't grow this
  // past roamingSettings' own size limit.
  var ROAMING_MAP_KEY = "graphicaConvSignatures";
  var ROAMING_MAP_MAX_ENTRIES = 500;

  // Bulletproof-fix marker: must match the literal text the Console embeds
  // at the end of every generated signature's HTML (see generate() /
  // SIGNATURE_MARKER_TEXT in signature-console-EDIT.html) and the
  // -MarkerText value Deploy-Signature.ps1 checks for server-side. If the
  // Console's marker text ever changes, this must be updated to match or
  // the recovery check below silently stops detecting anything.
  var SIGNATURE_MARKER_TEXT = "GraphicaSigMarkerV1";

  // True once an appendOnSendAsync recovery has been queued for the CURRENT
  // "marker went missing" episode (see checkMarkerAndRecover) — prevents
  // queuing a duplicate append on every 60s/focus check while the marker
  // stays missing. Reset to false the moment the marker is seen again.
  var pendingAppendQueued = false;

  var currentVariants = [];
  var currentSignatureData = null;
  // Either null (nothing decided/applied yet on this message — only possible
  // pre-load, or permanently on an older client that doesn't support
  // inserting anything), { kind: "default" }, or { kind: "variant", id: "…" }.
  var activeState = null;

  // How often to silently re-check the server for updates while the pane
  // stays open on the same message, on top of the "when the pane regains
  // focus" check below — a fallback for someone who never switches away
  // (e.g. composing in a single always-visible window).
  var AUTO_REFRESH_INTERVAL_MS = 60000;
  var isLoading = false;

  Office.onReady(function (info) {
    if (info.host !== Office.HostType.Outlook) return;
    cacheEls();
    els.refreshBtn.addEventListener("click", function () { loadSignature(false); });
    loadSignature(false);

    // Auto-refresh, so a change made in the Console shows up here without
    // anyone needing to remember to click Rafraîchir: silently on a timer,
    // and also the moment this window/pane gets focus again (switching back
    // from the Console in a browser tab, or from another app, is the most
    // common moment new data actually exists). "Silent" here only means no
    // full-panel loading flash and no error screen on a hiccup — see
    // loadSignature(silent) below. It never touches an already-chosen
    // signature already sitting in the body; it only refreshes what's
    // displayed and what's available to switch to.
    window.addEventListener("focus", function () { loadSignature(true); checkMarkerAndRecover(); });
    setInterval(function () { loadSignature(true); checkMarkerAndRecover(); }, AUTO_REFRESH_INTERVAL_MS);
  });

  function cacheEls() {
    els.stateLoading = document.getElementById("stateLoading");
    els.stateError = document.getElementById("stateError");
    els.stateContent = document.getElementById("stateContent");
    els.errorText = document.getElementById("errorText");
    els.sigCard = document.getElementById("sigCard");
    els.statusLine = document.getElementById("statusLine");
    els.variantsSection = document.getElementById("variantsSection");
    els.variantsList = document.getElementById("variantsList");
    els.refreshBtn = document.getElementById("refreshBtn");
    els.activeOverrideBar = document.getElementById("activeOverrideBar");
    els.activeOverrideLabel = document.getElementById("activeOverrideLabel");
    els.defaultReassureBox = document.getElementById("defaultReassureBox");
  }

  function showState(name) {
    ["stateLoading", "stateError", "stateContent"].forEach(function (k) {
      els[k].hidden = k !== name;
    });
  }

  // Mailbox requirement set 1.8 is what item.internetHeaders needs; without
  // it we fall back to the old copy-the-HTML flow instead of risking a
  // client-inserted signature that Exchange has no way to detect and skip
  // (which would double up with the transport rule's own stamp). Every
  // auto-insert/remember feature below is gated on this same check, so an
  // older client's experience is entirely untouched by any of it.
  function supportsOverrideInsert() {
    try {
      return Office.context.requirements.isSetSupported("Mailbox", "1.8");
    } catch (e) {
      return false;
    }
  }

  // Mailbox requirement set 1.9 is what item.body.appendOnSendAsync needs —
  // the API used below as a last-resort safety net when Outlook's own
  // native signature feature has silently wiped out ours mid-draft. A
  // client that doesn't support this simply has no recovery path; nothing
  // else here changes for it.
  function supportsAppendOnSend() {
    try {
      return Office.context.requirements.isSetSupported("Mailbox", "1.9");
    } catch (e) {
      return false;
    }
  }

  // silent=false (the normal Rafraîchir click, and the very first load of a
  // new compose window): shows the full loading screen, and a real error
  // screen if something goes wrong. silent=true (the focus/timer
  // auto-refresh): never flashes the loading screen and never replaces the
  // panel with an error screen — a network hiccup during a background
  // refresh should be invisible, not disruptive; it only shows a brief
  // status-line note, same as any other transient error here.
  function loadSignature(silent) {
    if (isLoading) return;
    isLoading = true;
    if (!silent) showState("stateLoading");

    var email = "";
    try {
      email = (Office.context.mailbox.userProfile.emailAddress || "").trim();
    } catch (e) {
      /* fall through to the error below */
    }

    if (!email) {
      isLoading = false;
      if (silent) return;
      showError("Impossible de déterminer votre adresse courriel dans Outlook. Réessayez, ou avisez l'administratrice.");
      return;
    }

    // Same-origin call — the API is served by the same Cloudflare Pages
    // project as this task pane, so no CORS setup is needed.
    fetch("/api/signature?email=" + encodeURIComponent(email), { cache: "no-store" })
      .then(function (res) {
        if (res.status === 404) {
          throw { friendly: "Aucune signature trouvée pour " + email + " pour l'instant. Demandez à l'administratrice de synchroniser la Console, ou vérifiez que votre adresse y est bien enregistrée." };
        }
        if (!res.ok) {
          throw { friendly: "Erreur du serveur (" + res.status + "). Réessayez dans un instant." };
        }
        return res.json();
      })
      .then(function (data) {
        currentSignatureData = data;
        currentVariants = data.variants || [];
        readActiveOverride(function (state) {
          if (state || !supportsOverrideInsert()) {
            // Either this message already has a choice on it (an earlier
            // open, or an earlier click, already set the headers — leave it
            // exactly as it is), or this client can't insert anything at all
            // (old-client fallback, unchanged from before this feature). A
            // silent auto-refresh always lands here after the first load,
            // since the headers are already set by then — it only ever
            // refreshes what's displayed, never the body.
            activeState = state;
            renderSignature(data);
            isLoading = false;
            checkMarkerAndRecover();
          } else {
            // Nothing chosen yet on this message, and this client can
            // insert — decide what belongs here (default for a new email,
            // or whatever was last used in this conversation for a reply/
            // forward) and apply it right away so the body isn't left
            // empty. This only happens on a message's very first load.
            decideInitialSignature(data, function (chosen) {
              applySignature(chosen, function () {
                renderSignature(data);
                isLoading = false;
                checkMarkerAndRecover();
              });
            });
          }
        });
      })
      .catch(function (err) {
        isLoading = false;
        var friendly = (err && err.friendly) || "Impossible de charger votre signature pour l'instant. Vérifiez votre connexion et réessayez.";
        if (silent) {
          showTransientError(friendly);
        } else {
          showError(friendly);
        }
      });
  }

  // Reads back whatever this panel (or an earlier open of it, on the same
  // message) already set, so re-opening or clicking Rafraîchir doesn't lose
  // track of "a signature is already active for this email" and doesn't
  // clobber an in-progress choice by re-running the auto-insert logic.
  function readActiveOverride(callback) {
    if (!supportsOverrideInsert()) { callback(null); return; }
    try {
      Office.context.mailbox.item.internetHeaders.getAsync([OVERRIDE_HEADER_NAME, OVERRIDE_VARIANT_HEADER_NAME], function (res) {
        if (res.status !== Office.AsyncResultStatus.Succeeded || !res.value) { callback(null); return; }
        var flag = res.value[OVERRIDE_HEADER_NAME];
        var raw = res.value[OVERRIDE_VARIANT_HEADER_NAME];
        if (flag && flag.trim() === OVERRIDE_HEADER_VALUE && raw) {
          var id = raw.trim();
          callback(id === DEFAULT_SENTINEL ? { kind: "default" } : { kind: "variant", id: id });
        } else {
          callback(null);
        }
      });
    } catch (e) {
      callback(null);
    }
  }

  // Figures out whether Office.js reports this compose window as a brand-new
  // email or a Reply/Reply All/Forward. Outlook reports Reply and Reply All
  // as the same "reply" compose type — there's no separate value for Reply
  // All — which is fine here since both are handled identically. Falls back
  // to treating it as a new email (the safest default — never worse than
  // today's "always show the everyday signature") if the API isn't
  // available or errors for any reason.
  function getComposeTypeSafe(callback) {
    try {
      Office.context.mailbox.item.getComposeTypeAsync(function (res) {
        if (res.status === Office.AsyncResultStatus.Succeeded && res.value && res.value.composeType) {
          callback(res.value.composeType);
        } else {
          callback(Office.MailboxEnums.ComposeType.NewMail);
        }
      });
    } catch (e) {
      callback(Office.MailboxEnums.ComposeType.NewMail);
    }
  }

  function getConversationId(callback) {
    try {
      callback(Office.context.mailbox.item.conversationId || null);
    } catch (e) {
      callback(null);
    }
  }

  function loadConvMap() {
    try {
      var raw = Office.context.roamingSettings.get(ROAMING_MAP_KEY);
      return raw && typeof raw === "object" ? raw : {};
    } catch (e) {
      return {};
    }
  }

  // Best-effort only — a failure here should never block someone from
  // actually sending their email, so every error is swallowed.
  function rememberSignatureForConversation(convId, chosenId) {
    if (!convId) return;
    try {
      var map = loadConvMap();
      if (!(convId in map)) {
        var keys = Object.keys(map);
        if (keys.length >= ROAMING_MAP_MAX_ENTRIES) {
          delete map[keys[0]];
        }
      }
      map[convId] = chosenId;
      Office.context.roamingSettings.set(ROAMING_MAP_KEY, map);
      Office.context.roamingSettings.saveAsync(function () { /* best-effort */ });
    } catch (e) { /* best-effort only */ }
  }

  // New email -> the everyday signature, immediately. Reply/Reply All/
  // Forward -> whatever was last used anywhere in this conversation, if
  // anything; otherwise the everyday signature, same as a new email.
  function decideInitialSignature(data, callback) {
    getComposeTypeSafe(function (composeType) {
      if (composeType === Office.MailboxEnums.ComposeType.NewMail) {
        callback({ kind: "default" });
        return;
      }
      getConversationId(function (convId) {
        if (!convId) { callback({ kind: "default" }); return; }
        var remembered = loadConvMap()[convId];
        if (remembered && remembered !== DEFAULT_SENTINEL) {
          var v = (data.variants || []).find(function (x) { return x.id === remembered; });
          if (v) { callback({ kind: "variant", id: v.id }); return; }
        }
        callback({ kind: "default" });
      });
    });
  }

  function htmlForState(state) {
    if (!state) return "";
    if (state.kind === "default") {
      return (currentSignatureData && currentSignatureData.defaultHtmlResolved) || "";
    }
    var v = currentVariants.find(function (x) { return x.id === state.id; });
    return (v && v.html) || "";
  }

  // Inserts the given signature (default or a specific variant) into the
  // message body and flags the message so Exchange's transport rule skips
  // its own stamp on this one email (see the header comment at the top of
  // this file). Also remembers this choice against the conversation, if
  // this message belongs to one, so later replies/forwards in the same
  // thread pick it up automatically. If either the insert or the header
  // write fails partway, this surfaces a clear message instead of leaving
  // someone unsure whether it worked.
  function applySignature(state, callback) {
    var html = htmlForState(state);
    Office.context.mailbox.item.body.setSignatureAsync(html, { coercionType: Office.CoercionType.Html }, function (res) {
      if (res.status !== Office.AsyncResultStatus.Succeeded) {
        showTransientError("Impossible d'insérer automatiquement cette signature. Réessayez, ou avisez l'administratrice.");
        callback && callback(false);
        return;
      }
      var idForHeader = state.kind === "default" ? DEFAULT_SENTINEL : state.id;
      var headers = {};
      headers[OVERRIDE_HEADER_NAME] = OVERRIDE_HEADER_VALUE;
      headers[OVERRIDE_VARIANT_HEADER_NAME] = idForHeader;
      Office.context.mailbox.item.internetHeaders.setAsync(headers, function (res2) {
        if (res2.status !== Office.AsyncResultStatus.Succeeded) {
          showTransientError("La signature a été insérée, mais votre signature habituelle pourrait s'ajouter aussi à l'envoi — avisez l'administratrice si les deux apparaissent.");
        }
        activeState = state;
        // The signature we just inserted carries the marker fresh — clear
        // any stale "recovery already queued" flag from a previous episode
        // on this same message (e.g. they'd switched to a native signature,
        // triggered a recovery, then clicked back to one of ours here).
        pendingAppendQueued = false;
        getConversationId(function (convId) {
          if (convId) rememberSignatureForConversation(convId, idForHeader);
        });
        callback && callback(true);
      });
    });
  }

  // Bulletproof-fix safety net. Only meaningful once a signature (default or
  // variant) has actually been applied (activeState set) — before that
  // there's nothing to verify. Checks whether the compose body still
  // contains our invisible marker text. Most of the time it will (nothing
  // touched the body). If it's gone — most commonly because the person
  // picked one of their own saved native Outlook signatures from Outlook's
  // own menu, which silently replaces the ENTIRE body we inserted, marker
  // included — and this client supports appendOnSendAsync, this queues our
  // signature to be appended back onto the message at the exact moment Send
  // is clicked, no matter what the body looks like by then.
  //
  // This is a SAFETY NET for the final sent email, not a fix for what's on
  // screen: the visible preview here can still show no Graphica signature
  // (or the wrong one) while a native signature is showing in the body —
  // there is no way to prevent that visual replacement itself (see
  // conversation history / manifest.xml for why). What this guarantees is
  // that the signature still gets added when the message actually goes out.
  //
  // pendingAppendQueued avoids stacking a duplicate queued append on every
  // 60s/focus check while the marker stays missing — appendOnSendAsync
  // itself replaces any previously queued append-on-send content each time
  // it's called, so calling it repeatedly wouldn't stack multiple
  // signatures either, but there's no reason to keep re-queuing identical
  // content every minute.
  function checkMarkerAndRecover() {
    if (!activeState) return;
    if (!supportsAppendOnSend()) return;
    try {
      Office.context.mailbox.item.body.getAsync(Office.CoercionType.Html, function (res) {
        if (res.status !== Office.AsyncResultStatus.Succeeded) return;
        var bodyHtml = res.value || "";
        var present = bodyHtml.indexOf(SIGNATURE_MARKER_TEXT) !== -1;
        if (present) {
          pendingAppendQueued = false;
          return;
        }
        if (pendingAppendQueued) return;
        var html = htmlForState(activeState);
        if (!html) return;
        Office.context.mailbox.item.body.appendOnSendAsync(html, { coercionType: Office.CoercionType.Html }, function (res2) {
          if (res2.status === Office.AsyncResultStatus.Succeeded) {
            pendingAppendQueued = true;
          }
          // A failure here is silently retried on the next check cycle
          // (under a minute later) — no user-facing error, since this only
          // matters at Send time.
        });
      });
    } catch (e) { /* best-effort only */ }
  }

  function showError(msg) {
    els.errorText.textContent = msg;
    showState("stateError");
  }

  function esc(s) {
    return String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }

  function renderSignature(data) {
    var infoHtml = '<div class="sig-name">' + esc(data.displayName || "(nom)") + "</div>";
    infoHtml += '<div class="sig-title">' + esc(data.title || "") + "</div>";
    if (data.phone) {
      infoHtml += '<div class="sig-line"><span class="dot-icon"></span><a href="tel:' + esc(data.phone) + '">' + esc(data.phone) + "</a></div>";
    }
    if (data.email) {
      infoHtml += '<div class="sig-line"><span class="dot-icon"></span><a href="mailto:' + esc(data.email) + '">' + esc(data.email) + "</a></div>";
    }
    if (data.websiteUrl) {
      infoHtml += '<div class="sig-line"><span class="dot-icon"></span><a href="' + esc(data.websiteUrl) + '" target="_blank" rel="noopener">' + esc(data.websiteLabel || data.websiteUrl) + "</a></div>";
    }

    var html;
    if (data.logoUrl) {
      html = '<div class="sig-header">' +
        '<div class="sig-logo"><img src="' + esc(data.logoUrl) + '" alt="' + esc(data.companyName || "Logo") + '"></div>' +
        '<div class="sig-divider"></div>' +
        '<div class="sig-info">' + infoHtml + "</div>" +
        "</div>";
    } else {
      html = infoHtml;
    }

    if (data.bannerHtmlPreview) {
      html += '<div class="sig-banner">' + data.bannerHtmlPreview + "</div>";
    }
    if (data.promoHtmlPreview) {
      html += '<div class="sig-promo">' + data.promoHtmlPreview + "</div>";
    }
    els.sigCard.innerHTML = html;

    var syncedLabel = "À jour avec la Console";
    if (data.syncedAt) {
      try {
        var d = new Date(data.syncedAt);
        syncedLabel = "Synchronisé le " + d.toLocaleString("fr-CA");
      } catch (e) { /* keep default label */ }
    }
    els.statusLine.innerHTML = '<span class="dot"></span> ' + esc(syncedLabel);

    currentVariants = data.variants || [];
    renderVariants();
    renderActiveOverrideBar();
    showState("stateContent");
  }

  // Shows/hides the green "a signature is active for this email" banner, and
  // (only for a client that can't insert anything) the old preview-only
  // reassurance text.
  function renderActiveOverrideBar() {
    var canInsert = supportsOverrideInsert();
    if (!canInsert) {
      els.activeOverrideBar.hidden = true;
      els.defaultReassureBox.hidden = false;
      return;
    }
    els.defaultReassureBox.hidden = true;
    if (!activeState) {
      els.activeOverrideBar.hidden = true;
      return;
    }
    els.activeOverrideBar.hidden = false;
    if (activeState.kind === "default") {
      els.activeOverrideLabel.textContent = "habituelle";
    } else {
      var v = currentVariants.find(function (x) { return x.id === activeState.id; });
      els.activeOverrideLabel.textContent = '« ' + ((v && v.label) || "personnalisée") + ' »';
    }
  }

  function renderVariants() {
    if (supportsOverrideInsert()) {
      renderVariantsInteractive();
    } else {
      renderVariantsFallback();
    }
  }

  // The full interactive list — "Signature habituelle" plus every variant,
  // any of which can be clicked at any time to swap what's in the body right
  // now (replacing whatever was there before, never stacking two).
  function renderVariantsInteractive() {
    els.variantsSection.hidden = false;
    els.variantsList.innerHTML = "";

    var entries = [{ kind: "default", id: null, label: "Signature habituelle" }].concat(
      currentVariants.map(function (v) {
        return { kind: "variant", id: v.id, label: v.label || "Variante" };
      })
    );

    entries.forEach(function (entry) {
      var isActive = !!activeState && activeState.kind === entry.kind &&
        (entry.kind === "default" || activeState.id === entry.id);
      var item = document.createElement("div");
      item.className = "variant-item" + (isActive ? " active" : "");
      var labelHtml = esc(entry.label) + (isActive ? '<span class="v-active-tag">✓ Utilisée</span>' : "");
      item.innerHTML =
        '<div class="v-label">' + labelHtml + "</div>" +
        '<button type="button" class="use-btn"' + (isActive ? " disabled" : "") + '>' +
        (isActive ? "Utilisée pour ce courriel" : "Utiliser cette signature") + "</button>";
      if (!isActive) {
        item.querySelector(".use-btn").addEventListener("click", function () {
          var target = entry.kind === "default" ? { kind: "default" } : { kind: "variant", id: entry.id };
          applySignature(target, function (ok) {
            if (ok) {
              renderVariants();
              renderActiveOverrideBar();
            }
          });
        });
      }
      els.variantsList.appendChild(item);
    });
  }

  // Unchanged from before this feature: an older client that can't insert
  // anything into the body still gets a plain list of variants to copy as
  // HTML and paste into Outlook's own Signatures settings themselves. The
  // everyday signature was never listed here (it always came from Exchange
  // alone on these clients), so it stays that way.
  function renderVariantsFallback() {
    if (!currentVariants.length) {
      els.variantsSection.hidden = true;
      return;
    }
    els.variantsSection.hidden = false;
    els.variantsList.innerHTML = "";
    currentVariants.forEach(function (v, idx) {
      var item = document.createElement("div");
      item.className = "variant-item";
      item.innerHTML =
        '<div class="v-label">' + esc(v.label || "Variante " + (idx + 1)) + "</div>" +
        '<button type="button" data-copy-idx="' + idx + '">Copier le code HTML</button><span class="copied" hidden>Copié !</span>' +
        '<p class="v-note">Collez-le comme nouvelle signature dans Outlook (Paramètres → Courrier → Composer et répondre → Signatures).</p>';
      var copyBtn = item.querySelector("[data-copy-idx]");
      var copiedTag = item.querySelector(".copied");
      copyBtn.addEventListener("click", function () {
        copyHtml(v.html || "").then(function () {
          copiedTag.hidden = false;
          setTimeout(function () { copiedTag.hidden = true; }, 2000);
        });
      });
      els.variantsList.appendChild(item);
    });
  }

  // A short-lived inline error, separate from the full-panel stateError view
  // (which would otherwise hide the variants list the person is actively
  // using) — surfaced via the same statusLine element already on screen.
  function showTransientError(msg) {
    var prev = els.statusLine.innerHTML;
    els.statusLine.innerHTML = '<span class="dot" style="background:#b3311f;"></span> ' + esc(msg);
    setTimeout(function () { els.statusLine.innerHTML = prev; }, 4000);
  }

  // Copies both an HTML flavor and a plain-text flavor, so pasting into a
  // rich-text editor (like Outlook's own Signatures box) renders the actual
  // formatted signature instead of raw tag text. Falls back to plain text
  // if the browser/host denies the richer clipboard write. Only used now on
  // clients too old to support direct insertion.
  function copyHtml(html) {
    if (navigator.clipboard && window.ClipboardItem) {
      try {
        var item = new ClipboardItem({
          "text/html": new Blob([html], { type: "text/html" }),
          "text/plain": new Blob([html], { type: "text/plain" })
        });
        return navigator.clipboard.write([item]).catch(function () {
          return copyPlain(html);
        });
      } catch (e) {
        return copyPlain(html);
      }
    }
    return copyPlain(html);
  }

  function copyPlain(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(text).catch(function () {});
    }
    return Promise.resolve();
  }
})();
