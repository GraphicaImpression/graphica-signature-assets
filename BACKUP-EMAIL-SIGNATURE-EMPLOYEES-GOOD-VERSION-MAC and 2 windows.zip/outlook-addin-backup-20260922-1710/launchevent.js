// Graphica Signature — background send-time safety check (Smart Alerts /
// OnMessageSend). Runs automatically the instant someone clicks Send, on
// EVERY outgoing message, regardless of whether the "Aperçu signature" task
// pane was ever opened for that email.
//
// WHY THIS FILE EXISTS: the task pane's own recovery check (in
// taskpane.js's checkMarkerAndRecover) only runs while the pane is actually
// open on screen — Outlook stops running a task pane's code the moment it's
// closed. Real usage can't guarantee the pane stays open: someone opens it
// once (which inserts the everyday signature and sets the header below),
// closes it, then picks one of their own saved native Outlook signatures —
// wiping out everything we inserted, marker included, with no pane left
// open to notice. This handler is the backstop that ALWAYS fires at the
// moment of Send, closed pane or not.
//
// WHY THIS BLOCKS INSTEAD OF SILENTLY FIXING THE EMAIL: Office.js's
// appendOnSendAsync (the API that can invisibly queue content to be
// inserted at send) is documented to return an ERROR if called from inside
// this exact on-send handler — it can only be queued earlier, while still
// composing, which is exactly what taskpane.js's own recovery already does
// for as long as the pane stays open. There is no supported way to
// silently rewrite the message body from here. So instead: if the marker
// is missing, this briefly blocks the send with a clear message and a
// button that reopens the pane, where the signature can be reinserted with
// the normal, always-available setSignatureAsync path — then the person
// sends again. If the marker IS present (the normal case, every time
// nothing was touched), nothing happens and the send proceeds exactly as
// before, with no visible change at all.
//
// Must match SIGNATURE_MARKER_TEXT in taskpane.js and the Console's
// generate() (signature-console-EDIT.html). If the Console's marker text
// ever changes, update this too, or this check silently stops working.
var SIGNATURE_MARKER_TEXT = "GraphicaSigMarkerV1";
var OVERRIDE_HEADER_NAME = "X-Graphica-Signature-Override";
var OVERRIDE_HEADER_VALUE = "true";

// The ribbon button's id in manifest.xml — used so the block message can
// offer a button that reopens the task pane directly, instead of just
// telling someone where to click.
var SIGNATURE_BUTTON_COMMAND_ID = "GraphicaSigButton";

function onMessageSendHandler(event) {
  try {
    Office.context.mailbox.item.body.getAsync(
      Office.CoercionType.Html,
      { asyncContext: event },
      onBodyRead
    );
  } catch (e) {
    // Never let an unexpected error here hold up someone's email — fail
    // OPEN (allow the send) rather than fail closed. A missed check is far
    // better than every employee suddenly unable to send mail.
    event.completed({ allowEvent: true });
  }
}

function onBodyRead(asyncResult) {
  var event = asyncResult.asyncContext;
  if (asyncResult.status !== Office.AsyncResultStatus.Succeeded) {
    event.completed({ allowEvent: true });
    return;
  }
  var bodyHtml = asyncResult.value || "";

  try {
    Office.context.mailbox.item.internetHeaders.getAsync(
      [OVERRIDE_HEADER_NAME],
      { asyncContext: { event: event, bodyHtml: bodyHtml } },
      onHeaderRead
    );
  } catch (e) {
    event.completed({ allowEvent: true });
  }
}

function onHeaderRead(asyncResult) {
  var event = asyncResult.asyncContext.event;
  var bodyHtml = asyncResult.asyncContext.bodyHtml;

  var headerPresent = false;
  if (asyncResult.status === Office.AsyncResultStatus.Succeeded && asyncResult.value) {
    var flag = asyncResult.value[OVERRIDE_HEADER_NAME];
    headerPresent = !!(flag && flag.trim() === OVERRIDE_HEADER_VALUE);
  }

  if (!headerPresent) {
    // The add-in was never used to insert anything into this particular
    // message (most employees, most of the time — the everyday signature
    // still comes from the Exchange transport rule for anyone who never
    // opens the pane at all). Nothing to check here; let it go through
    // exactly as it always has.
    event.completed({ allowEvent: true });
    return;
  }

  var markerPresent = bodyHtml.indexOf(SIGNATURE_MARKER_TEXT) !== -1;
  if (markerPresent) {
    event.completed({ allowEvent: true });
    return;
  }

  // Header says the add-in inserted a signature into this message, but the
  // marker is gone from the body — the exact "picked a native personal
  // signature afterward" scenario. Block briefly, explain what happened in
  // plain language, and offer a one-click way back to fixing it.
  event.completed({
    allowEvent: false,
    errorMessage: "Votre signature Graphica a été retirée de ce courriel (probablement en choisissant une de vos signatures personnelles Outlook). Cliquez sur « Aperçu signature » dans le ruban pour la réinsérer, puis renvoyez.",
    errorMessageMarkdown: "Votre signature Graphica a été retirée de ce courriel — probablement en choisissant une de vos signatures personnelles Outlook après coup.\n\n**Pour corriger :** cliquez sur **Aperçu signature** dans le ruban, choisissez une signature dans la liste, puis renvoyez ce courriel.",
    cancelLabel: "Rouvrir Aperçu signature",
    commandId: SIGNATURE_BUTTON_COMMAND_ID
  });
}

Office.actions.associate("onMessageSendHandler", onMessageSendHandler);

// ---------------------------------------------------------------------------
// OnNewMessageCompose - auto-insert the signature the instant a compose
// window opens, without needing the task pane open at all.
//
// WHY THIS EXISTS: before this, the signature only appeared in the body once
// someone clicked "Aperçu signature" to open the task pane - taskpane.js's
// own loadSignature()/decideInitialSignature() did the actual insert, but
// only ran once that pane's JS loaded. This event runs the same decision
// (default for a new email, or whatever was last used in this conversation
// for a reply/forward - see decideInitialSignatureShared below) the moment
// the compose window itself opens, so the signature is already there before
// anyone touches the ribbon button.
//
// CONFIRMED VIA MICROSOFT'S OWN DOCS/ISSUE TRACKER before building this:
//   - Requires Mailbox requirement set 1.10 (this manifest's V1_1 block
//     already requires 1.15 for the OnMessageSend check, so no separate
//     bump was needed).
//   - Runs even when the task pane is closed - by design, this is the point.
//   - Is NOT limited to brand-new mail: Microsoft's own tracker
//     (OfficeDev/office-js#2915) confirms it also fires for Reply and
//     Forward (even forwarding a meeting invite, on some clients) - which is
//     exactly why this handler re-runs the same "default vs. remembered
//     conversation choice" decision as the task pane, instead of always
//     forcing the default signature.
//   - Two OPEN, UNRESOLVED bugs exist in Microsoft's own office-js issue
//     tracker for this exact event + setSignatureAsync combination:
//     (a) office-js#4680 - on some Classic Outlook for Windows builds,
//     the insert can be delayed by 5+ minutes; (b) office-js#5483 - on
//     some cross-client draft scenarios, setSignatureAsync has been seen to
//     ADD a signature instead of replacing one already there, letting two
//     stack up. Neither is something this code can work around - they are
//     platform bugs. This is why this was deployed as a careful, isolated
//     test (see conversation history) rather than assumed reliable from the
//     documentation alone: WATCH FOR duplicate or delayed signatures during
//     testing, especially on Windows.
//   - Never blocks anything - no SendMode applies here (that's an
//     OnMessageSend-only concept). If this fails, times out, or the runtime
//     is unavailable, the compose window is completely unaffected - someone
//     can still click "Aperçu signature" themselves exactly as before this
//     was added, so this is purely additive.
//
// Key name/value constants (OVERRIDE_HEADER_NAME, OVERRIDE_HEADER_VALUE,
// SIGNATURE_MARKER_TEXT) are declared once above and reused here.
var OVERRIDE_VARIANT_HEADER_NAME = "X-Graphica-Signature-Variant-Id";
var DEFAULT_SENTINEL = "__default__";
var ROAMING_MAP_KEY = "graphicaConvSignatures";

// CONFIRMED VIA A SMOKE TEST ON 2026-09-15: OnNewMessageCompose does not
// reach this account's Outlook client at all - not a bug in this handler's
// logic. The test version of this function set the compose window's subject
// line immediately, with zero dependency on fetch/signatures/headers/
// anything that could itself silently fail; the subject never changed. That
// isolates the problem to Microsoft's platform itself: this exact event is
// documented (Microsoft's own developer Q&A/forums) to simply not fire for
// some users/clients with no released fix, independent of manifest or code
// correctness. Left in place (inert until Microsoft fixes their bug) rather
// than removed, since it costs nothing to keep and starts working the
// moment that happens - see conversation history for the full diagnosis.
function onNewMessageComposeHandler(event) {
  try {
    // If this compose window somehow already has our headers set (observed
    // in practice on some forward-of-an-already-flagged-message edge cases),
    // leave it alone - don't re-decide or re-insert on top of an existing
    // choice. Mirrors taskpane.js's own readActiveOverride guard.
    Office.context.mailbox.item.internetHeaders.getAsync(
      [OVERRIDE_HEADER_NAME, OVERRIDE_VARIANT_HEADER_NAME],
      { asyncContext: event },
      onExistingHeadersChecked
    );
  } catch (e) {
    safeComplete(event);
  }
}

// Guards against ever calling event.completed() more than once (harmless
// per Office.js, but sloppy) or never calling it at all - which is exactly
// the failure mode Microsoft's own troubleshooting notes describe for this
// event: an uncaught exception anywhere in the handler chain makes the
// whole thing look like it silently "didn't fire," with no error surfaced
// anywhere, because Outlook is just left waiting for a completion signal
// that never comes.
function safeComplete(event) {
  if (!event || event.__graphicaCompleted) return;
  event.__graphicaCompleted = true;
  try { event.completed(); } catch (e) { /* nothing more we can do */ }
}

function onExistingHeadersChecked(asyncResult) {
  var event = asyncResult.asyncContext;
  try {
    if (asyncResult.status === Office.AsyncResultStatus.Succeeded && asyncResult.value) {
      var flag = asyncResult.value[OVERRIDE_HEADER_NAME];
      if (flag && flag.trim() === OVERRIDE_HEADER_VALUE) {
        // Already decided (shouldn't normally happen on a brand-new compose,
        // but safe to no-op if it does) - nothing to do.
        safeComplete(event);
        return;
      }
    }

    var email = "";
    try {
      email = (Office.context.mailbox.userProfile.emailAddress || "").trim();
    } catch (e) { /* fall through */ }

    if (!email) {
      safeComplete(event);
      return;
    }

    // CONFIRMED VIA MICROSOFT'S OWN TROUBLESHOOTING NOTES for this exact
    // event (learn.microsoft.com/answers/questions/782902): an uncaught
    // exception this early in the handler makes the whole event look like
    // it silently never fired, no error visible anywhere. fetch() may not
    // exist at all in this background runtime (it's more restricted than
    // the task pane's), so check for it explicitly rather than assuming -
    // calling an undefined function here would throw synchronously and,
    // without this guard, do exactly that.
    if (typeof fetch !== "function") {
      safeComplete(event);
      return;
    }

    fetch("/api/signature?email=" + encodeURIComponent(email), { cache: "no-store" })
      .then(function (res) {
        if (!res.ok) throw new Error("signature fetch failed: " + res.status);
        return res.json();
      })
      .then(function (data) {
        try {
          decideInitialSignatureShared(data, function (chosen) {
            insertSignatureAndComplete(chosen, data, event);
          });
        } catch (e) {
          safeComplete(event);
        }
      })
      .catch(function () {
        // No signature data available (offline, sync not run yet, a fetch
        // failure, etc.) - do nothing and let the compose window proceed
        // untouched. The task pane button remains available as the manual
        // fallback, same as always.
        safeComplete(event);
      });
  } catch (e) {
    // Final safety net - whatever went wrong, never leave Outlook waiting
    // on a completion signal that never arrives.
    safeComplete(event);
  }
}

// Same decision taskpane.js's decideInitialSignature makes: brand-new mail
// (or any compose type this event fires for that isn't a tracked reply/
// forward) gets the everyday signature; a reply/forward reuses whatever was
// last chosen anywhere in that conversation, if anything was recorded.
function decideInitialSignatureShared(data, callback) {
  var composeType = null;
  try {
    Office.context.mailbox.item.getComposeTypeAsync(function (res) {
      composeType = (res.status === Office.AsyncResultStatus.Succeeded && res.value) ? res.value.composeType : null;
      afterComposeType();
    });
  } catch (e) {
    afterComposeType();
  }

  function afterComposeType() {
    try {
      if (composeType !== Office.MailboxEnums.ComposeType.Reply &&
          composeType !== Office.MailboxEnums.ComposeType.Forward) {
        callback({ kind: "default" });
        return;
      }
      var convId = null;
      try { convId = Office.context.mailbox.item.conversationId || null; } catch (e) { /* ignore */ }
      if (!convId) { callback({ kind: "default" }); return; }
      var map = {};
      try {
        var raw = Office.context.roamingSettings.get(ROAMING_MAP_KEY);
        map = raw && typeof raw === "object" ? raw : {};
      } catch (e) { /* ignore */ }
      var remembered = map[convId];
      if (remembered && remembered !== DEFAULT_SENTINEL) {
        var v = (data.variants || []).find(function (x) { return x.id === remembered; });
        if (v) { callback({ kind: "variant", id: v.id }); return; }
      }
      callback({ kind: "default" });
    } catch (e) {
      callback({ kind: "default" });
    }
  }
}

function insertSignatureAndComplete(chosen, data, event) {
  try {
    var html;
    if (chosen.kind === "default") {
      html = (data && data.defaultHtmlResolved) || "";
    } else {
      var v = (data.variants || []).find(function (x) { return x.id === chosen.id; });
      html = (v && v.html) || "";
    }
    if (!html) { safeComplete(event); return; }

    Office.context.mailbox.item.body.setSignatureAsync(html, { coercionType: Office.CoercionType.Html }, function (res) {
      try {
        if (res.status !== Office.AsyncResultStatus.Succeeded) {
          // Insert failed - leave the compose window as-is; the task pane
          // button is still there as a manual fallback. Don't block anything.
          safeComplete(event);
          return;
        }
        var idForHeader = chosen.kind === "default" ? DEFAULT_SENTINEL : chosen.id;
        var headers = {};
        headers[OVERRIDE_HEADER_NAME] = OVERRIDE_HEADER_VALUE;
        headers[OVERRIDE_VARIANT_HEADER_NAME] = idForHeader;
        Office.context.mailbox.item.internetHeaders.setAsync(headers, function () {
          // Best-effort remember, same as taskpane.js's rememberSignatureForConversation.
          try {
            var convId = Office.context.mailbox.item.conversationId || null;
            if (convId) {
              var map = {};
              try {
                var raw = Office.context.roamingSettings.get(ROAMING_MAP_KEY);
                map = raw && typeof raw === "object" ? raw : {};
              } catch (e) { /* ignore */ }
              map[convId] = idForHeader;
              Office.context.roamingSettings.set(ROAMING_MAP_KEY, map);
              Office.context.roamingSettings.saveAsync(function () { /* best-effort */ });
            }
          } catch (e) { /* best-effort only */ }
          safeComplete(event);
        });
      } catch (e) {
        safeComplete(event);
      }
    });
  } catch (e) {
    safeComplete(event);
  }
}

Office.actions.associate("onNewMessageComposeHandler", onNewMessageComposeHandler);
